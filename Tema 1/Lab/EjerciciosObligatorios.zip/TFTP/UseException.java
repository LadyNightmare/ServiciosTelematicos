package TFTP;

/******************************
 * 
 * Asignatura: Desarrollo de Servicios Telemáticos
 * Autora: Cristina Díaz García
 * 
*******************************/

public class UseException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UseException() {
		super();
	}

	public UseException(String s) {
		super(s);
	}
}