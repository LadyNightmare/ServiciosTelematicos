/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */
package MyPackage;

/**
 *
 * @author as203061
 */
public class Calculator {
 public int calcSum(int a, int b) {
        return a + b;
    }    
}
