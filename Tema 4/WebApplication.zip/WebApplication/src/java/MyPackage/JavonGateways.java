//GEN-BEGIN:Client
/**
 * This file is generated. Please do not change
 */
package MyPackage;

import java.io.*;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Invocation Gateways
 */
public class JavonGateways {
    /**
     *  This class implements the application server connectivity specific to the needs.
     *  MyPackage.Calculator
     */
    public static class MyPackage_CalculatorcalcSum1Gateway implements InvocationAbstraction {

        /**
         *  This method performs the actual invocation of server functionality. It is
         *  used by the servlet to delegate functionality to external classes.
         *
         * @param input The stream from which we should read the parameters for the methods
         * @return The return value for the method NULL IS NOT SUPPORTED!!!!
         * @throws Exception  Thrown when a protocol error occurs
         */
        public Object invoke(HttpSession session, DataInput input) throws Exception {
            int a = ((Integer)Utility.readObject( input )).intValue();
            int b = ((Integer)Utility.readObject( input )).intValue();
             
            MyPackage.Calculator instance = (MyPackage.Calculator)session .getAttribute("MyPackage.Calculator");
            if (instance == null) {
                instance = (MyPackage.Calculator) Class.forName("MyPackage.Calculator").newInstance();
                session.setAttribute("MyPackage.Calculator", instance);
            }
                    return new Integer(instance.calcSum(a, b));
        }

        public int[] getIds() {
            return new int[] {
                    1,
                    1
                };
        };

        public int[] getReturnIds() {
            return new int[] {
                1
                };
        };
    }

    private static Object readObject(DataInput in) throws IOException {
        return Utility.readObject(in);
    }
}
//GEN-END:Client
