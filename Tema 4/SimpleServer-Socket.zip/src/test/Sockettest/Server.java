package test.Sockettest;

/* SERVIDOR   
 * Creado por Sebastian Cipolat
 * */

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	Socket skCliente;
	ServerSocket skServidor;
	String datareceived, substring1, substring2;
	final int PUERTO = 5555;// Puerto que utilizara el servidor utilizar este
							// mismo en el cliente
	String IP_client;
	Mensaje_data mdata = null;
	ObjectOutputStream oos = null;
	String TimeStamp;

	Server() {

		try {
			System.out.println("************ SERVER ****************");
			// creamos server socket
			skServidor = new ServerSocket(PUERTO);
			System.out.println("Escuchando el puerto " + PUERTO);
			System.out.println("En Espera....");

			TimeStamp = new java.util.Date().toString();

			try {
				// Creamos socket para manejar conexion con cliente
				skCliente = skServidor.accept(); // esperamos al cliente
				// una vez que se conecta obtenemos la ip
				IP_client = skCliente.getInetAddress().toString();
				System.out.println("[" + TimeStamp + "] Conectado al cliente "
						+ "IP:" + IP_client);

				while (true) {
					// Manejamos flujo de Entrada
					ObjectInputStream ois = new ObjectInputStream(
							skCliente.getInputStream());
					// Cremos un Objeto con lo recibido del cliente
					Object aux = ois.readObject();// leemos objeto

					// si el objeto es una instancia de Mensaje_data
					if (aux instanceof Mensaje_data) {
						// casteamos el objeto
						mdata = (Mensaje_data) aux;

						// Analizamos el mensaje recibido
						// si no es el mensaje FINAL
						if (!mdata.last_msg) {
								System.out.println("[" + TimeStamp + "] "
										+ "Mensaje de [" + IP_client + "]--> "
										+ mdata.texto);						
						} else {// cerramos socket
							skCliente.close();
							ois.close();
							System.out
									.println("["
											+ TimeStamp
											+ "] Ultimo mensaje detectado Conexion cerrada, gracias vuelva pronto");
							break;
						}
					} else {
						// Si no es del tipo esperado, se marca error
						System.err.println("Mensaje no esperado ");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("[" + TimeStamp + "] Error ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + TimeStamp + "] Error ");
		}
	}

	
	public static void main(String[] args) {
		new Server();
	}
}	