package com.example.apachehttpclient;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

import com.example.apachehttpclient.R;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


@TargetApi(Build.VERSION_CODES.GINGERBREAD)
@SuppressLint("NewApi")
public class ActHttpClient extends Activity {
	
    /** Called when the activity is first created. */
    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@SuppressLint("NewApi")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Permite realizar acciones bloqueantes en la hebra del layout      
        StrictMode.ThreadPolicy.Builder policy = new StrictMode.ThreadPolicy.Builder().permitAll();
        StrictMode.setThreadPolicy(policy.build());
       
        final EditText txtUrl = (EditText)findViewById(R.id.url);
        final Button btnFetch = (Button)findViewById(R.id.button);
        final TextView txtResult = (TextView)findViewById(R.id.content);
   
        btnFetch.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
            	try {
                if (isNetworkAvailable(txtResult)) {
                	String url = txtUrl.getText().toString();
                	String result=ConectarApache(txtResult,url);
                	// El codigo HTML de la pagina resultado se muestra por pantalla
                	txtResult.setText(result);
                }
            	} catch (Exception ex) {
            		txtResult.setText("Error de conexion .....!"+ex.getClass().toString());
            	}
            }
        });
    }
    
    // Verificar que tenemos conexion a Internet
 	private boolean isNetworkAvailable(TextView txtResult) {
 		ConnectivityManager cm = (ConnectivityManager)
 		getSystemService(Context.CONNECTIVITY_SERVICE);
 		NetworkInfo networkInfo = cm.getActiveNetworkInfo();
 		if (networkInfo != null && networkInfo.isConnected()) {
 			txtResult.setText("Red habilitada");
 		  return true;
 		}
 		else {
 			txtResult.setText("Red no disponible");
 			return false; 
 		}
 	}

    // Conexion con un servidor web usando los paquetes de Apache
    private String ConectarApache(TextView txtResult, String urlS) {
		 StringBuffer paginaWeb = new StringBuffer();
		 try {
		   HttpClient client = new DefaultHttpClient();
		   HttpContext localContext = new BasicHttpContext();
		   HttpGet request = new HttpGet(urlS);
		 
		   
		   HttpResponse response = client.execute(request, localContext);
		 
		   BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		   String line = "";
		   while ((line = rd.readLine()) != null) {
		     paginaWeb.append(line);
		   }
		 }
		 catch (Exception e) {
		   txtResult.setText("Error en la conexion con el servidor .....!");
		   e.printStackTrace();
		   return paginaWeb.toString();
		 }
		 return paginaWeb.toString();
    }

}